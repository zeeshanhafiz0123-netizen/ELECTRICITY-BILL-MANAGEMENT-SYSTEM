# Student Record Portal — HTML/CSS/JavaScript

A responsive frontend-only Student Record Management Portal.

## Features
- New user registration
- Old user login using **Email + Phone only** (no password)
- Account-scoped student records
- Add, search, edit and delete students
- Guardian name and guardian phone
- Student email and phone
- Fees tracking
- Dashboard and reports
- Responsive UI for Android, phones, tablets and laptops
- Small SR logo
- Uses browser `localStorage`; no backend, framework or server required

## Run
Open `index.html` in a browser. For GitHub Pages, upload these files to a repository and enable Pages.

## Important limitation
Because this version uses only HTML, CSS and JavaScript with browser localStorage, data is stored separately in each browser/device. It cannot synchronize records between a phone and laptop by itself. True cross-device online synchronization requires a backend/cloud database or an external service/API, which would violate the requested frontend-only constraint.
